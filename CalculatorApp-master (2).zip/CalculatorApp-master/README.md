# CalculatorApp
Started on 01 March 2016

An andoid application which performs the functions of a basic calculator, scientific calculator and unit converter.
You can run this projects's apk file on any android mobile phone and work on this project using android studios.

## Screenshorts:

* Main Screen:

<div>
  <img src="https://github.com/anubhavshrimal/CalculatorApp/blob/master/screenshorts/device-2016-11-02-205344.png" alt="Main Screen" height="700dp">
</div>

---

* Standard Calc & History of Calc:

<div>
  <img src="https://github.com/anubhavshrimal/CalculatorApp/blob/master/screenshorts/device-2016-11-02-205030.png" alt="Standard Calc" height="700dp">
   <img src="https://github.com/anubhavshrimal/CalculatorApp/blob/master/screenshorts/device-2016-11-02-205138.png" alt="History of Calc" height="700dp">
</div>

---

* Scientific Calc:

<div>
  <img src="https://github.com/anubhavshrimal/CalculatorApp/blob/master/screenshorts/device-2016-11-02-205154.png" alt="Scientific Calc" height="700dp">
  <img src="https://github.com/anubhavshrimal/CalculatorApp/blob/master/screenshorts/device-2016-11-02-205226.png" alt="Scientific Calc-2" height="700dp">
</div>

---

* Unit Converter:

<div>
  <img src="https://github.com/anubhavshrimal/CalculatorApp/blob/master/screenshorts/device-2016-11-02-205241.png" alt="Unit Converter-1" height="700dp">
    <img src="https://github.com/anubhavshrimal/CalculatorApp/blob/master/screenshorts/device-2016-11-02-205326.png" alt="Unit Converter-2" height="700dp">
</div>

---
